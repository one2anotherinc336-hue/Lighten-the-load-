# Lighten the Load — Stage 2 starter

## Included
- `index.html`: responsive prototype with breathing sessions, demo points, sample gift-card catalog, private-by-default testimonial submissions, moderation preview, and nickname stored on the current device.
- `manifest.webmanifest` and `sw.js`: basic installable/offline PWA scaffolding.
- `supabase_schema.sql`: starting database schema with row-level security.

## Run locally
Open `index.html` in a browser. For PWA install/offline features, serve it from localhost or an HTTPS host (for example GitHub Pages).

## Publish for free
1. Create a GitHub repository.
2. Upload all four files to the repository root.
3. In Settings → Pages, select Deploy from a branch, `main`, `/root`.
4. Open the generated HTTPS URL on a phone. Browser install options vary by device.

## Important limits
This is still a prototype. The profile is device-local, not a real account. Points are demonstration points only. Sample gift cards are not real offers. Testimonial moderation is a local demonstration and is NOT a secure moderator system. Do not collect real users' stories or promise rewards with this version.

## Connect Supabase later
1. Create a Supabase project and keep its database credentials private.
2. Review `supabase_schema.sql` and run it in Supabase SQL Editor.
3. Implement real authentication, server-side session validation, points ledger, moderator roles, consent and deletion workflows before accepting users.
4. Never put a Supabase service-role key in browser code. Use only a publishable/anon key in a frontend with correct RLS policies; sensitive rewards and points logic must run server-side.
5. Have a qualified privacy/legal reviewer assess age eligibility, parental consent, applicable child privacy rules, gift-card terms, tax and consumer-protection obligations before public launch.

## Safer launch policy
- Do not onboard children under 13 until the required parental-consent and legal-compliance process has been designed and reviewed.
- For teens, minimize data, avoid public real names, disable direct messaging and location sharing, and use age-appropriate moderation.
- Ask for separate, informed permission before publishing a testimonial. Let users withdraw it.
- Do not collect breathing audio. A timer is enough to record session completion.
- Do not describe the app as therapy or a treatment.
