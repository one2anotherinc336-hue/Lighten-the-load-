-- Lighten the Load: initial Supabase schema
-- Run in Supabase SQL Editor only after creating a new project.
-- This schema intentionally does not store breathing audio or public legal names.

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null check (char_length(display_name) between 1 and 24),
  age_band text not null check (age_band in ('13-15','16-17','18+')),
  created_at timestamptz not null default now()
);

create table public.sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  duration_seconds integer not null check (duration_seconds in (60,120,180,300)),
  points_awarded integer not null default 10 check (points_awarded in (0,10)),
  completed_at timestamptz not null default now()
);

create table public.testimonials (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 600),
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now()
);

create table public.reward_catalog (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  points_cost integer not null check (points_cost > 0),
  active boolean not null default false,
  inventory integer not null default 0 check (inventory >= 0),
  sponsor_name text,
  terms text
);

create table public.redemptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  reward_id uuid not null references public.reward_catalog(id),
  status text not null default 'requested' check (status in ('requested','approved','fulfilled','declined')),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.sessions enable row level security;
alter table public.testimonials enable row level security;
alter table public.reward_catalog enable row level security;
alter table public.redemptions enable row level security;

create policy "Users can read own profile" on public.profiles for select using (auth.uid() = id);
create policy "Users can insert own profile" on public.profiles for insert with check (auth.uid() = id);
create policy "Users can update own profile" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);

create policy "Users can read own sessions" on public.sessions for select using (auth.uid() = user_id);
create policy "Users can insert own sessions" on public.sessions for insert with check (auth.uid() = user_id);

create policy "Users can read own testimonials" on public.testimonials for select using (auth.uid() = user_id);
create policy "Users can submit own testimonials" on public.testimonials for insert with check (auth.uid() = user_id);
-- Public approved-story reads and moderator update policies must be added only
-- after trusted moderator roles and consent workflows are implemented.

create policy "Anyone can view active rewards" on public.reward_catalog for select using (active = true);
create policy "Users can read own redemptions" on public.redemptions for select using (auth.uid() = user_id);
create policy "Users can request own redemption" on public.redemptions for insert with check (auth.uid() = user_id);
